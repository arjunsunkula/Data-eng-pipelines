import logging
import pandas as pd
from google.cloud import storage
from pandas_gbq import to_gbq

logging.basicConfig(level=logging.INFO)


def gcs_trigger(data, context):
    """Triggered by a change in Cloud Storage. This function processes CSV and loads data to BigQuery."""

    bucket_name = data['bucket']
    file_name = data['name']

    logging.info(f"Processing file {file_name} from bucket {bucket_name}")

    try:
        # Initialize storage client
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(file_name)

        # Download file
        temp_file_path = "/tmp/temp_file.csv"
        blob.download_to_filename(temp_file_path)

        # Read into DataFrame
        df = pd.read_csv(temp_file_path)

        # Upload to BigQuery
        dataset_id = "trainee_dataset"
        table_id = "user_data"
        to_gbq(df, f"data-eng-454009.{dataset_id}.{table_id}", project_id="data-eng-454009", if_exists='append')

        logging.info(f"File {file_name} processed and uploaded to BigQuery successfully.")

    except Exception as e:
        logging.error(f"Error processing file {file_name}: {e}")
